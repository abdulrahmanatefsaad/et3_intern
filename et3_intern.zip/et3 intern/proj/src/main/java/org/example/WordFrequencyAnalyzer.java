package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class WordFrequencyAnalyzer {

    public static void analyzeWordFrequency(String filepath) {
        Map<String, Integer> wordCounts = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String cleanedLine = line.replaceAll("[^\\p{L}\\p{N}\\s]", "").toLowerCase();
                Pattern pattern = Pattern.compile("\\b\\w+\\b");
                Matcher matcher = pattern.matcher(cleanedLine);
                while (matcher.find()) {
                    String word = matcher.group();
                    wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            return;
        }

        List<Map.Entry<String, Integer>> topWords = wordCounts.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .limit(10)
                .collect(Collectors.toList());

        System.out.println("\nTop 10 most frequent words in " + filepath + ":");
        topWords.forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue()));
        displayBarChart(topWords, filepath);
    }

    private static void displayBarChart(List<Map.Entry<String, Integer>> topWords, String filepath) {
        JFrame frame = new JFrame("Word Frequency Bar Chart");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int panelWidth = getWidth();
                int panelHeight = getHeight();
                int barWidth = panelWidth / (topWords.size() * 2);
                int maxCount = topWords.stream().mapToInt(Map.Entry::getValue).max().orElse(1);
                int padding = 50;

                g2d.drawLine(padding, padding, padding, panelHeight - padding);
                g2d.drawLine(padding, panelHeight - padding, panelWidth - padding, panelHeight - padding);

                for (int i = 0; i < topWords.size(); i++) {
                    Map.Entry<String, Integer> entry = topWords.get(i);
                    int barHeight = (int) ((double) entry.getValue() / maxCount * (panelHeight - 2 * padding));
                    int x = padding + i * (barWidth + barWidth);
                    int y = panelHeight - padding - barHeight;

                    g2d.setColor(Color.BLUE);
                    g2d.fillRect(x, y, barWidth, barHeight);

                    g2d.setColor(Color.BLACK);
                    g2d.translate(x + barWidth / 2, panelHeight - padding + 10);
                    g2d.rotate(-Math.PI / 4);
                    g2d.drawString(entry.getKey(), 0, 0);
                    g2d.rotate(Math.PI / 4);
                    g2d.translate(-(x + barWidth / 2), -(panelHeight - padding + 10));

                    g2d.drawString(String.valueOf(entry.getValue()), x + barWidth / 2 - 10, y - 5);
                }

                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                g2d.drawString("Top 10 Words in " + new java.io.File(filepath).getName(), padding, 30);
            }
        };

        frame.add(chartPanel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        String filePath;

        if (args.length >= 1) {
            filePath = args[0];
        } else {
            filePath = "/Users/abodyatef/Downloads/internship_challenge_solution/README.md";
        }

        analyzeWordFrequency(filePath);
    }
}